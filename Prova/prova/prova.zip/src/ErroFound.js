import React from "react"

function ErroFound(){
  return (
  <><h1>Erro 404</h1>
  <h3>Not Found</h3></>
  
  )
}

export default ErroFound